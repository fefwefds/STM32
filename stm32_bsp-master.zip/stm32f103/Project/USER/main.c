#include "headfile.h"

int main()
{

	while (1)
	{
		/* code */
	}
}
