#ifndef _ZN_USART_H
#define _ZN_USART_H
#define DEBUG_USART   USART1

void usart_Init(UARTX_ENUM uartn,uint32 baud ,UARTX_ENUM_IO tx_pin,UARTX_ENUM_IO rx_pin);
void uart_putchar(UARTX_ENUM uartn, uint8 dat);
void uart_putbuff(UARTX_ENUM uartn, uint8 *buff, uint32 len);
void uart_putstr(UARTX_ENUM uartn, const uint8 *str);
void Usart_Send_uint16( UARTX_ENUM uartn, uint16_t dat);
void uart_getchar(UARTX_ENUM uartn, uint8 *dat);
uint8 uart_query(UARTX_ENUM uartn, uint8 *dat);
void uart_tx_irq(UARTX_ENUM uartn, uint32 status,uint16_t Pre, uint16_t Sub );
void uart_rx_irq(UARTX_ENUM uartn, uint32 status,uint16_t Pre, uint16_t Sub);
int fputc(int dat, FILE *f);
int fgetc(FILE *f);







#endif