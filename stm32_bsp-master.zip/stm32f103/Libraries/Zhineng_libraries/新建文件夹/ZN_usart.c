#include "headfile.h"
/*****************************************************
* @file				UART
* @Software			IAR 8.3 or MDK 5.28
* @auther                       JIA
* @version                      v1.0
* @Target core		         stm32f407zg
* @date				2021-08-07
****************************************************/

USART_TypeDef *uart_index[6] = {USART1, USART2, USART3, UART4, UART5, USART6};
IRQn_Type uart_irq[8] = {USART1_IRQn, USART2_IRQn, USART3_IRQn, UART4_IRQn, UART5_IRQn, USART6_IRQn};
/*-------------------------------------------------------------------------------------------------------------------
// @brief	��ʼ������	
// @param		uartn			(USART_1,USART_2)
// @param		baud			������
// @param		tx_pin			tx����
// @param		rx_pin			rx����
// @return		void        
// Sample usage:				usart_Init(USART_1,115200,USART1_TX_A9,USART1_RX_A10);										
//-------------------------------------------------------------------------------------------------------------------**/
void usart_Init(UARTX_ENUM uartn,uint32 baud ,UARTX_ENUM_IO tx_pin,UARTX_ENUM_IO rx_pin)
{
  int t_gpio,t_pin,r_gpio,r_pin;
  GPIO_InitTypeDef GPIO_InitStructure;
  uint8_t AF_MODE;
  uint32_t GPIO_PIN_TX_XX;
  uint32_t GPIO_PIN_RX_XX;
  USART_InitTypeDef USART_InitStructure;
     
     t_gpio = tx_pin / 17;
     t_pin  = tx_pin % 17;
     r_gpio = rx_pin / 17;
     r_pin  = rx_pin % 17;
     
     switch(uartn)
  {
    case USART_1 :AF_MODE=GPIO_AF_USART1;
      break;
    case USART_2 :AF_MODE=GPIO_AF_USART2;
      break;
    case USART_3 :AF_MODE=GPIO_AF_USART3;
      break;
    case USART_6 :AF_MODE=GPIO_AF_USART6;
      break;
    case UART_4 :AF_MODE=GPIO_AF_UART4;
      break;
    case UART_5 :AF_MODE=GPIO_AF_UART5;
      break;
    
  }
  
  switch(uartn)
  {
    case USART_1 :
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);break;
    case USART_2 :
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);break;
    case USART_3 :
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);break;
    case USART_6 :
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6,ENABLE);break;
    case UART_4 :
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);break;
    case UART_5 :
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5,ENABLE);break;
      break;
    
  }
     /* GPIO */
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  
       switch(t_pin) 
     {
          case 0: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource0;
                  break;
          case 1: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource1;
                  break;
          case 2: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource2;
                  break;
          case 3: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource3;
                  break;
          case 4: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource4;
                  break;
          case 5: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource5;
                  break;
          case 6: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource6;
                  break;
          case 7: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource7;
                  break;
          case 8: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource8;
                  break;
          case 9: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource9;
                  break;
          case 10: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource10;
                  break;
          case 11: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource11;
                  break;
          case 12: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource12;
                  break;
          case 13: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource13;
                  break;
          case 14: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource14;
                  break;
          case 15:
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15; //�? 
            GPIO_PIN_TX_XX = GPIO_PinSource15;
                  break;
                  
     }
  
 
  switch(t_gpio)
  {
  case 0:  
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA,GPIO_PIN_TX_XX,AF_MODE); break;
  case 1:  
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOB,GPIO_PIN_TX_XX,AF_MODE); break;
  case 2:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOC,GPIO_PIN_TX_XX,AF_MODE); break;
  case 3:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOD,GPIO_PIN_TX_XX,AF_MODE); break;
  case 4:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOE,GPIO_PIN_TX_XX,AF_MODE); break;
  case 5: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE);
    GPIO_Init(GPIOF, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOF,GPIO_PIN_TX_XX,AF_MODE); break;
  case 6:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE);
    GPIO_Init(GPIOG, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOG,GPIO_PIN_TX_XX,AF_MODE); break;
  case 7: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH,ENABLE);
    GPIO_Init(GPIOH, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOH,GPIO_PIN_TX_XX,AF_MODE); break;
  case 8:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI,ENABLE);
    GPIO_Init(GPIOI, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOI,GPIO_PIN_TX_XX,AF_MODE); break;
  case 9: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOJ,ENABLE);
    GPIO_Init(GPIOJ, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOJ,GPIO_PIN_TX_XX,AF_MODE); break;
  case 10: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOK,ENABLE);
    GPIO_Init(GPIOK, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOK,GPIO_PIN_TX_XX,AF_MODE); break;
  }
  
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  
  switch(r_pin) 
     {
          case 0: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource0;
                  break;
          case 1: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource1;
                  break;
          case 2: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource2;
                  break;
          case 3: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource3;
                  break;
          case 4: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource4;
                  break;
          case 5: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5; //�?
            GPIO_PIN_RX_XX = GPIO_PinSource5;
                  break;
          case 6: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource6;
                  break;
          case 7: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource7;
                  break;
          case 8: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource8;
                  break;
          case 9: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource9;
                  break;
          case 10: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource10;
                  break;
          case 11: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11; //�?
            GPIO_PIN_RX_XX = GPIO_PinSource11;
                  break;
          case 12: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource12;
                  break;
          case 13: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource13;
                  break;
          case 14: 
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource14;
                  break;
          case 15:
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15; //�? 
            GPIO_PIN_RX_XX = GPIO_PinSource15;
                  break;
                  
     }
  switch(r_gpio)
  {
  case 0: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA,GPIO_PIN_RX_XX,AF_MODE); break;
  case 1:  
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOB,GPIO_PIN_RX_XX,AF_MODE); break;
  case 2:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOC,GPIO_PIN_RX_XX,AF_MODE); break;
  case 3:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD,ENABLE);
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOD,GPIO_PIN_RX_XX,AF_MODE); break;
  case 4:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOE,GPIO_PIN_RX_XX,AF_MODE); break;
  case 5: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF,ENABLE);
    GPIO_Init(GPIOF, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOF,GPIO_PIN_RX_XX,AF_MODE); break;
  case 6:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOG,ENABLE);
    GPIO_Init(GPIOG, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOG,GPIO_PIN_RX_XX,AF_MODE); break;
  case 7: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH,ENABLE);
    GPIO_Init(GPIOH, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOH,GPIO_PIN_RX_XX,AF_MODE); break;
  case 8:
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI,ENABLE);
    GPIO_Init(GPIOI, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOI,GPIO_PIN_RX_XX,AF_MODE); break;
  case 9: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOJ,ENABLE);
    GPIO_Init(GPIOJ, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOJ,GPIO_PIN_RX_XX,AF_MODE); break;
  case 10: 
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOK,ENABLE);
    GPIO_Init(GPIOK, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOK,GPIO_PIN_RX_XX,AF_MODE); break;
  }
   
  
  USART_InitStructure.USART_BaudRate = baud;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No ;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  
  USART_Init(uart_index[uartn], &USART_InitStructure);
  USART_Cmd(uart_index[uartn], ENABLE);

}
/*-------------------------------------------------------------------------------------------------------------------
// @brief		���ڵ��ֽڷ�������
// @param		uartn			(USART_1,USART_2)
// @param		dat				
// @return		void        
// Sample usage:				uart_putchar(USART_1,0xA5);										// 눔왯1랙箇0xA5
//-------------------------------------------------------------------------------------------------------------------**/
void uart_putchar(UARTX_ENUM uartn, uint8 dat)
{
  uart_index[uartn]->DR = dat;
		
	
	while (! USART_GetFlagStatus(uart_index[uartn], USART_FLAG_TXE));											// 된덤랙箇供냥
}
/*-------------------------------------------------------------------------------------------------------------------
// @brief		���ڷ�����������
// @param		uartn			(USART_1,USART_2)
// @param		*buff			
// @param		len				
// @return		void
// Sample usage:				uart_putbuff(USART_1,&a[0],5);
//-------------------------------------------------------------------------------------------------------------------*/
void uart_putbuff(UARTX_ENUM uartn, uint8 *buff, uint32 len)
{
	while(len)																					// 琦뻔돕랙箇供
	{
		uart_index[uartn]->DR = *buff++;														// 畇흙랙箇鑒앴
		while(! USART_GetFlagStatus(uart_index[uartn], USART_FLAG_TXE));										// 된덤랙箇供냥
		len--;
	}
}
/*-------------------------------------------------------------------------------------------------------------------
// @brief		���ڷ����ַ���
// @param		uartn			(USART_1,USART_2)
// @param		*str			
// @return		void
// Sample usage:				uart_putstr(USART_1,"i lvoe you"); 
//-------------------------------------------------------------------------------------------------------------------*/
void uart_putstr(UARTX_ENUM uartn, const uint8 *str)
{
	while(*str)																					// 寧�??琦뻔돕써�?
	{
		uart_putchar(uartn, *str++);															// 랙箇鑒앴
	}
}
/*--------------------------------------------------------------------
// @brief		���ڷ�16λ����
// @param		uartn			(USART_1,USART_2)
// @param		dat			
// @return		void
// Sample usage:				uart_putstr(USART_1,OX1152); 
//-------------------------------------------------------------------*/
void Usart_Send_uint16( UARTX_ENUM uartn, uint16_t dat)
{
	uint8_t temp_h, temp_l;
	
	
	temp_h = (dat&0XFF00)>>8;
	
	temp_l = dat&0XFF;
	
	
	USART_SendData(uart_index[uartn],temp_h);	
	while (! USART_GetFlagStatus(uart_index[uartn], USART_FLAG_TXE));
	
	
	USART_SendData(uart_index[uartn],temp_l);	
	while (! USART_GetFlagStatus(uart_index[uartn], USART_FLAG_TXE));	
}

/*-------------------------------------------------------------------------------------------------------------------
// @brief		��ȡ��������while�ȴ�
// @param		uartn			(USART_1,USART_2)
// @param		*dat			
// @return		void        
// Sample usage:				uint8 dat; uart_getchar(USART_1,&dat);							// 쌈澗눔왯1鑒앴  닸瞳瞳dat긴�?�쟁
//-------------------------------------------------------------------------------------------------------------------*/
void uart_getchar(UARTX_ENUM uartn, uint8 *dat)
{
	while(!USART_GetFlagStatus(uart_index[uartn],USART_FLAG_RXNE));											// 된덤뗍혤돕�?��?�鑒�?
	*dat = (uint8)uart_index[uartn]->DR;
}

/*-------------------------------------------------------------------------------------------------------------------
// @brief		��ȡ�������ݲ�ѯ����
// @param		uartn			(USART_1,USART_2)
// @param		*dat			
// @return		uint8			1�?   0�?
// Sample usage:				uint8 dat; uart_query(USART_1,&dat);							// 쌈澗눔왯1鑒앴  닸瞳瞳dat긴�?�쟁
//-------------------------------------------------------------------------------------------------------------------*/
uint8 uart_query(UARTX_ENUM uartn, uint8 *dat)
{
	if(USART_GetFlagStatus(uart_index[uartn],USART_FLAG_RXNE)==1)													// 뗍혤돕�?��?�鑒�?
	{
		*dat = (uint8)uart_index[uartn]->DR;													// 닸뇨寧�?�鑒�?
		return 1;
	}
	return 0;
}

/*-------------------------------------------------------------------------------------------------------------------
// @brief		���ڿ��������ж�
// @param		uartn			(USART_1,USART_2)
// @param		status			1�?   0�?
// @param		Pre			
// @param		Sub			
// @return		void        
// Sample usage:				uart_tx_irq(USART_1,1,1,1);											// 댔역눔왯1랙箇供냥櫓뙤
//-------------------------------------------------------------------------------------------------------------------*/
void uart_tx_irq(UARTX_ENUM uartn, uint32 status,uint16_t Pre, uint16_t Sub )
{
	if(status)
		USART_ITConfig(uart_index[uartn], USART_IT_TXE, ENABLE);													// 賈콘랙箇供냥櫓뙤
	else
		USART_ITConfig(uart_index[uartn], USART_IT_TXE, DISABLE);												// 밑균랙箇供냥櫓뙤

	nvic_init(uart_irq[uartn], Pre, Sub, (FunctionalState)status);
}

/*-------------------------------------------------------------------------------------------------------------------
// @brief		���ڿ��������ж�
// @param		uartn			(USART_1,USART_2)
// @param		status			
// @param		Pre			
// @param		Sub			
// @return		void        
// Sample usage:				uart_rx_irq(USART_1,1,1,1);											// 댔역눔왯1쌈澗供냥櫓뙤
//-------------------------------------------------------------------------------------------------------------------*/
void uart_rx_irq(UARTX_ENUM uartn, uint32 status,uint16_t Pre, uint16_t Sub)
{
	if(status)
		USART_ITConfig(uart_index[uartn], USART_IT_RXNE, ENABLE);													// 賈콘쌈澗供냥櫓뙤
	else
		USART_ITConfig(uart_index[uartn], USART_IT_RXNE, DISABLE);												// 밑균쌈澗供냥櫓뙤

	nvic_init(uart_irq[uartn], Pre, Sub, (FunctionalState)status);
}

///
/*
*����printf��scanf�ض���
*/
int fputc(int dat, FILE *f)
{
		
		USART_SendData(DEBUG_USART, (uint8_t) dat);
		
		
		while (USART_GetFlagStatus(DEBUG_USART, USART_FLAG_TXE) == RESET);		
	
		return (dat);
}
///
int fgetc(FILE *f)
{
		
		while (USART_GetFlagStatus(DEBUG_USART, USART_FLAG_RXNE) == RESET);

		return (int)USART_ReceiveData(DEBUG_USART);
}