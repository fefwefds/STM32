/*********************************************************************************************************************
* @file				timer
* @company			����������Ӽ�
* @author			С��
* @version			�鿴doc��version�ļ� �汾˵��
* @Software			IAR 8.3 or MDK 5.24
* @Target core		        stm32f407
* @Taobao			
* @date				2021-07-29
********************************************************************************************************************/

#include "headfile.h"




//-------------------------------------------------------------------------------------------------------------------
//  @brief      ��ʱ���жϳ�ʼ��
//  @param      timerx        ��ʱ�����
//  @param      time          ��ʱʱ��
//  @param      sec           ��ʱ����Ƶ�ж�msʱΪ1��usʱΪ0��
//  @param      interrupt     �����ж����ȼ�ʮλΪ��ռ���ȼ���λΪ�����ȼ�
//  @return     void
//  @since      v1.0
//  Sample usage:               TIM_Init(TIMER3,50,ms,1,3);	��ռ���ȼ� 1  �����ȼ� 3	
//-------------------------------------------------------------------------------------------------------------------
TIM_TimeBaseInitTypeDef  TIMX_Handler;
void TIM_Init(TIMERX_ENUM Tim_n, uint32 time, uint32 sec, uint16 inter1, uint16 inter2)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  
  uint16 tim_n, psc = 0, arr = 0 ;
  
  tim_n = Tim_n ;
  
  switch(sec)
  {
     case 0:
       {
         psc=90;
         arr=time;
         
       }break;
         
     case 1:
       {
         psc=9000;
         arr=time*10;      //�˴�����֮ǰ�ο�ѧ����   �Լ����Ժ������ڲ�̫�Ծ��Ͷ�*0.5��
                           //�������ѽ��  ���ھ���Ƶ��  ����stm32f4xx.h ���޸� HSE_Value
       }break;
         
  }
    //Tout=((arr+1)*(psc+1))/f;��ʱ������ʱ��Ƶ��Ϊsys/2 180/2=90m   ��Ƶ�ǵø�pscֵ
  
  TIMX_Handler.TIM_Period =arr-1; //�Զ���װ��ֵ
  TIMX_Handler.TIM_Prescaler=psc-1; //��ʱ����Ƶ
  TIMX_Handler.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
  TIMX_Handler.TIM_ClockDivision=TIM_CKD_DIV1;
  
  /*------�����������ж�ʱ����д�ģ�������Щ�����ˣ�û��ϸ������Ϊ��Ķ���ʹ-----*/
  /*------------��������ͬ���ѽ�����ж�λ�ŵ�ַ��ͬ����stm32f4xx�в鿴----------*/
  switch(tim_n)
  {
//û���ҵ���ʱ��1�Ͷ�ʱ�� 8 ��ȫ���ж�  global interrupt    
//     case 0:
//       {
//         
//         RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE); //ʹ�� TIM ʱ��
//         
//         NVIC_InitStructure.NVIC_IRQChannel=TIM1_TRG_COM_TIM11_IRQn; //��ʱ�� 1 �ж�   �߼���ʱ��
//         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ� 
//         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ� 
//         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
//         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
//       }break;
     case 1:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); //ʹ�� TIM ʱ��
         
         TIM_TimeBaseInit(TIM2,&TIMX_Handler);// ��ʼ����ʱ�� TIMx
         TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE); //������ʱ��  �����ж�

         TIM_Cmd(TIM2,ENABLE); //ʹ�ܶ�ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM2_IRQn; //��ʱ�� 2 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ� 
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ� 
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 2:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //ʹ�� TIM ʱ��
         
         TIM_TimeBaseInit(TIM3,&TIMX_Handler);// ��ʼ����ʱ�� TIMx
         TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE); //������ʱ��  �����ж�

         TIM_Cmd(TIM3,ENABLE); //ʹ�ܶ�ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn; //��ʱ�� 3 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ� 
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 3:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE); //ʹ�� TIM ʱ��
         
         TIM_TimeBaseInit(TIM4,&TIMX_Handler);// ��ʼ����ʱ�� TIMx
         TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE); //������ʱ��  �����ж�

         TIM_Cmd(TIM4,ENABLE); //ʹ�ܶ�ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM4_IRQn; //��ʱ�� 4 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 4:
       {
        
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE); //ʹ�� TIM ʱ��
         
         TIM_TimeBaseInit(TIM5,&TIMX_Handler);// ��ʼ����ʱ�� TIMx
         TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE); //������ʱ��  �����ж�

         TIM_Cmd(TIM5,ENABLE); //ʹ�ܶ�ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM5_IRQn; //��ʱ�� 5 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 5:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM6_DAC_IRQn; //��ʱ�� 6�ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 6:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE); //ʹ�� TIM ʱ��
         
         TIM_TimeBaseInit(TIM7,&TIMX_Handler);// ��ʼ����ʱ�� TIMx
         TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE); //������ʱ��  �����ж�

         TIM_Cmd(TIM7,ENABLE); //ʹ�ܶ�ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM7_IRQn; //��ʱ�� 7 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;  
//     case 7:
//       {
//        
//         RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE); //ʹ�� TIM ʱ��
//         
//         NVIC_InitStructure.NVIC_IRQChannel=TIM8_IRQn; //��ʱ�� 8 �ж�
//         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
//         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
//         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
//         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
//       }break;  
     case 8:
       {
         
         RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM1_BRK_TIM9_IRQn; //��ʱ�� 9 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 9:
       {
         
         RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM10, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM1_UP_TIM10_IRQn; //��ʱ�� 10 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;
     case 10:
       {
         
         RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM11, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM1_TRG_COM_TIM11_IRQn; //��ʱ�� 11 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break;    
     case 11:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM12, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM8_BRK_TIM12_IRQn; //��ʱ�� 12 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break; 
     case 12:
       {
         
         RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM8_UP_TIM13_IRQn; //��ʱ�� 13 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break; 
     case 13:
       {
         
         RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM11, ENABLE); //ʹ�� TIM ʱ��
         
         NVIC_InitStructure.NVIC_IRQChannel=TIM8_TRG_COM_TIM14_IRQn; //��ʱ�� 11 �ж�
         NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=inter1; //��ռ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelSubPriority=inter2; //��Ӧ���ȼ�
         NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
         NVIC_Init(&NVIC_InitStructure);// ��ʼ�� NVIC 
       }break; 
      
  }
  
  
  
  
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      pwm��ʼ��
//  @param      timx        ��ʱ������Լ�ͨ��
//  @param      freq           Ƶ��
//  @return     void
//  @since      v1.0
//  Sample usage:               TIM_PWM_Init(TIM2_CH1,50);	 ��ʱ��6 7  �������PWM	
//-------------------------------------------------------------------------------------------------------------------

void  TIM_PWM_Init(TIMX_ENUM timx,uint32 freq)
{
  uint16 psc=0,arr=0,tim_num,tim_ch;
  
  TIM_TimeBaseInitTypeDef TIM_Handler;  
  TIM_OCInitTypeDef  TIM_CHHandler;
  
  tim_num = timx / 5;   //ÿ����ʱ��ģ��ö����4��ͨ��
  tim_ch  = timx % 5;
  /*--��ȡʱ��Ƶ��--*/
  RCC_ClocksTypeDef  RCC_TIM_USE;
  RCC_GetClocksFreq(&RCC_TIM_USE);

  psc = (RCC_TIM_USE.SYSCLK_Frequency/2) / (freq * arr); //180M / 2 = 90M = 90 000 000
  
  if(psc<1) psc = 1;
  
  TIM_Handler.TIM_Prescaler=psc-1;   
  TIM_Handler.TIM_CounterMode=TIM_CounterMode_Up;//���ϼ���
  TIM_Handler.TIM_Period=arr-1;         
  TIM_Handler.TIM_ClockDivision=TIM_CKD_DIV1;
  
  TIM_CHHandler.TIM_OCMode = TIM_OCMode_PWM2; //PWM ����ģʽ 2
  TIM_CHHandler.TIM_OutputState = TIM_OutputState_Enable; //�Ƚ����ʹ��
  TIM_CHHandler.TIM_Pulse = 0; //Ĭ�ϳ�ʼ��ռ�ձ�Ϊ0
  TIM_CHHandler.TIM_OCPolarity = TIM_OCPolarity_High; //������Ը�

  /*--ע��TIM1 TIM8 ���ǹ����� APB2ʱ�������ϵ� �����Ķ�ʱ������ APB1 ����--*/
  switch(tim_num)
  {
    case 1:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); //ʹ�� PORTA ʱ��
        TIM_TimeBaseInit(TIM2,&TIM_Handler);
        
        TIM_OC1Init(TIM2, &TIM_CHHandler);  //��ʼ��TIM OC1����
        TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM2, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM2, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(A0, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(A1, AF, PULLUP, HIGH, PP);
        if(tim_ch==2 || tim_ch==4) IO_Init(A2, AF, PULLUP, HIGH, PP);
        if(tim_ch==3 || tim_ch==4) IO_Init(A3, AF, PULLUP, HIGH, PP);
        arr=TIM2_ARR;
        break;
      }
    case 2:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); 
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); 
        TIM_TimeBaseInit(TIM3,&TIM_Handler);
        
        TIM_OC1Init(TIM3, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM3, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM3, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(A6, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(A7, AF, PULLUP, HIGH, PP);
        if(tim_ch==2 || tim_ch==4) IO_Init(B0, AF, PULLUP, HIGH, PP);
        if(tim_ch==3 || tim_ch==4) IO_Init(B1, AF, PULLUP, HIGH, PP);
        arr=TIM3_ARR;
        break;
      }
    case 3:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); 
        TIM_TimeBaseInit(TIM4,&TIM_Handler);
        
        TIM_OC1Init(TIM4, &TIM_CHHandler); 
        TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM4, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM4, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(B6, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(B7, AF, PULLUP, HIGH, PP);
        if(tim_ch==2 || tim_ch==4) IO_Init(B8, AF, PULLUP, HIGH, PP);
        if(tim_ch==3 || tim_ch==4) IO_Init(B9, AF, PULLUP, HIGH, PP);
        arr=TIM4_ARR;
        break;
      }
    case 4:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOH, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI, ENABLE); 
        TIM_TimeBaseInit(TIM5,&TIM_Handler);
        
        TIM_OC1Init(TIM5, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM5, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM5, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM5, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(H10, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(H11, AF, PULLUP, HIGH, PP);
        if(tim_ch==2 || tim_ch==4) IO_Init(H12, AF, PULLUP, HIGH, PP);
        if(tim_ch==3 || tim_ch==4) IO_Init(I0, AF, PULLUP, HIGH, PP);
        arr=TIM5_ARR;
        break;
      }
    case 7:
      {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOI, ENABLE); 
        TIM_TimeBaseInit(TIM8,&TIM_Handler);
        
        TIM_OC1Init(TIM8, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM8, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM8, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM8, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(I5, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(I6, AF, PULLUP, HIGH, PP);
        if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM8_ARR;
        break;
      }
    case 8:
      {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE); 
        TIM_TimeBaseInit(TIM9,&TIM_Handler);
        
        TIM_OC1Init(TIM9, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM9, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM9, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM9, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(E5, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(E6, AF, PULLUP, HIGH, PP);
        //if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM9_ARR;
        break;
      }  
    case 9:
      {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM10, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE); 
        TIM_TimeBaseInit(TIM10,&TIM_Handler);
        
        TIM_OC1Init(TIM10, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM10, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM10, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM10, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(F6, AF, PULLUP, HIGH, PP);
        //if(tim_ch==1 || tim_ch==4) IO_Init(I6, AF, PULLUP, HIGH, PP);
        //if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM10_ARR;
        break;
      }  
    case 10:
      {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM11, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE); 
        TIM_TimeBaseInit(TIM11,&TIM_Handler);
        
        TIM_OC1Init(TIM11, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM11, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM11, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM11, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(F7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==1 || tim_ch==4) IO_Init(I6, AF, PULLUP, HIGH, PP);
        //if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM11_ARR;
        break;
      }  
    case 11:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM12, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); 
        TIM_TimeBaseInit(TIM12,&TIM_Handler);
        
        TIM_OC1Init(TIM12, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM12, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM12, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM12, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(B14, AF, PULLUP, HIGH, PP);
        if(tim_ch==1 || tim_ch==4) IO_Init(B15, AF, PULLUP, HIGH, PP);
        //if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM12_ARR;
        break;
      }  
    case 12:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE); 
        TIM_TimeBaseInit(TIM13,&TIM_Handler);
        
        TIM_OC1Init(TIM13, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM13, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM13, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM13, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(F8, AF, PULLUP, HIGH, PP);
        //if(tim_ch==1 || tim_ch==4) IO_Init(I6, AF, PULLUP, HIGH, PP);
        //if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM13_ARR;
        break;
      }  
    case 13:
      {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE); 
        TIM_TimeBaseInit(TIM14,&TIM_Handler);
        
        TIM_OC1Init(TIM14, &TIM_CHHandler);
        TIM_OC1PreloadConfig(TIM14, TIM_OCPreload_Enable); //ʹ��Ԥװ�ؼĴ���
        TIM_ARRPreloadConfig(TIM14, ENABLE);//ARPE ʹ��
        TIM_Cmd(TIM14, ENABLE);
        
        if(tim_ch==0 || tim_ch==4) IO_Init(F9, AF, PULLUP, HIGH, PP);
        //if(tim_ch==1 || tim_ch==4) IO_Init(I6, AF, PULLUP, HIGH, PP);
        //if(tim_ch==2 || tim_ch==4) IO_Init(I7, AF, PULLUP, HIGH, PP);
        //if(tim_ch==3 || tim_ch==4) IO_Init(I2, AF, PULLUP, HIGH, PP);
        arr=TIM14_ARR;
        break;
      }    
  }
  

}

/*
*    ���ò�ͬͨ�����ռ�ձ�
*/
void TIM_Duty1(TIM_TypeDef* TIMx,u32 compare1)
{
  TIMx->CCR1 = compare1;
}
void TIM_Duty2(TIM_TypeDef* TIMx,u32 compare2)
{
  TIMx->CCR2 = compare2;
}
void TIM_Duty3(TIM_TypeDef* TIMx,u32 compare3)
{
  TIMx->CCR3 = compare3;
}
void TIM_Duty4(TIM_TypeDef* TIMx,u32 compare4)
{
  TIMx->CCR4 = compare4;
}