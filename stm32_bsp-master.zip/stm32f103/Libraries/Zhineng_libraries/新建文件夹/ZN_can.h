#ifndef _ZN_CAN_H_
#define _ZN_CAN_H_

//   CAN���ź궨��
typedef enum {

     CAN1_RX_A11  = A11,  CAN1_TX_A12  = A12,
     CAN1_RX_D0   = D0,   CAN1_TX_D1   = D1,
     CAN1_RX_B8   = B8,   CAN1_TX_B9   = B9,
     CAN_2_RX_B12 = B12,  CAN_2_TX_B13 = B13,
     CAN_2_RX_B5  = B5,   CAN_2_TX_B6  = B6,
}CANX_ENUM_PIN;
//   CAN�궨��
typedef enum {

     CAN_1,
     CAN_2,
}CANX_ENUM;


void CAN_MODE_Init(CANX_ENUM canx,CANX_ENUM_PIN can_rx_pinx,CANX_ENUM_PIN can_tx_pinx,uint16_t Pre, uint16_t Sub);
void Init_RxMes(CanRxMsg *RxMessage);
__weak void CAN_SetMsg(CanTxMsg *TxMessage);
__weak void CAN_RX_IRQHandler(void);

#endif