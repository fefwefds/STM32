#ifndef _ZN_tim_h
#define _ZN_tim_h

#define TIM1_ARR  10000U
#define TIM2_ARR  10000U
#define TIM3_ARR  10000U
#define TIM4_ARR  10000U
#define TIM5_ARR  10000U
#define TIM6_ARR  10000U
#define TIM7_ARR  10000U
#define TIM8_ARR  10000U
#define TIM9_ARR  10000U
#define TIM10_ARR 10000U
#define TIM11_ARR 10000U
#define TIM12_ARR 10000U
#define TIM13_ARR 10000U
#define TIM14_ARR 10000U

#define ms 1
#define us 0



void TIM_Init(TIMERX_ENUM Tim_n, uint32 time, uint32 sec, uint16 inter1, uint16 inter2);
void  TIM_PWM_Init(TIMX_ENUM timx,uint32 freq);
void TIM_Duty1(TIM_TypeDef* TIMx,u32 compare1);
void TIM_Duty2(TIM_TypeDef* TIMx,u32 compare2);
void TIM_Duty3(TIM_TypeDef* TIMx,u32 compare3);
void TIM_Duty4(TIM_TypeDef* TIMx,u32 compare4);





















#endif