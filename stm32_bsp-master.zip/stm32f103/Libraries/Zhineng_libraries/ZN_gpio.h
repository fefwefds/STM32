#ifndef _ZN_GPIO_H
#define _ZN_GPIO_H

/*
typedef enum
{ 
  GPIO_Speed_10MHz = 1,
  GPIO_Speed_2MHz, 
  GPIO_Speed_50MHz
}GPIOSpeed_TypeDef;
*/
/*
typedef enum
{ GPIO_Mode_AIN = 0x0,
  GPIO_Mode_IN_FLOATING = 0x04,
  GPIO_Mode_IPD = 0x28,
  GPIO_Mode_IPU = 0x48,
  GPIO_Mode_Out_OD = 0x14,
  GPIO_Mode_Out_PP = 0x10,
  GPIO_Mode_AF_OD = 0x1C,
  GPIO_Mode_AF_PP = 0x18
}GPIOMode_TypeDef;
*/


void IO_Init(GPIO_PIN gpio_pin,GPIOMode_TypeDef mode,GPIOSpeed_TypeDef speed );
void IO_set(GPIO_PIN gpio_pin,u8 date);
uint8_t IO_read(GPIO_PIN gpio_pin);
void IO_toggle(GPIO_PIN gpio_pin);
#endif
