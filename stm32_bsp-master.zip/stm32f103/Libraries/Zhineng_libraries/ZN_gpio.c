/*****************************************************
 * @file				gpio
 * @company			����������Ӽ�
 * @Software			IAR 8.3 or MDK 5.28
 * @auther                       JIA
 * @version                      v1.0
 * @Target core		         stm32f407zg
 * @date				2021-07-29
 ****************************************************/
#include "headfile.h"

char clk_a = 0, clk_b = 0, clk_c = 0, clk_d = 0, clk_e = 0, clk_f = 0,
     clk_g = 0, clk_h = 0, clk_i = 0, clk_j = 0, clk_k = 0;

//-------------------------------------------------------------------------------------------------------------------
//  @brief      IO�ڳ�ʼ��
//  @param      gpio_pin        ���ź�
//  @param      mode            ģʽ
//  @param      speed           �ٶ�
//  @return     void
//  @since      v1.0
//  Sample usage:               IO_Init(G9,GPIO_Mode_Out_PP,GPIO_Speed_50MHz);		//����PG9Ϊ�������ģʽ���������������100M
//-------------------------------------------------------------------------------------------------------------------

void IO_Init(GPIO_PIN gpio_pin, GPIOMode_TypeDef mode, GPIOSpeed_TypeDef speed)
{

        GPIO_InitTypeDef GPIO_InitStructure;

        int gpio, pin;

        gpio = gpio_pin / 17;
        pin = gpio_pin % 17;

        switch (gpio) //�򿪶�Ӧʱ��
        {

        // A
        case 0:
                if (!clk_a)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
                        clk_a = 1;
                }
                break;

        // B
        case 1:
                if (!clk_b)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
                        clk_b = 1;
                }
                break;

        // C
        case 2:
                if (!clk_c)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
                        clk_c = 1;
                }
                break;

        // D
        case 3:
                if (!clk_d)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
                        clk_d = 1;
                }
                break;

        // E
        case 4:
                if (!clk_e)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
                        clk_e = 1;
                }
                break;

        // F
        case 5:
                if (!clk_f)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF, ENABLE);
                        clk_f = 1;
                }
                break;

        // G
        case 6:
                if (!clk_g)
                {
                        RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG, ENABLE);
                        clk_g = 1;
                }
                break;
        }
        switch (pin) //ѡ���Ӧ����
        {
        case 0:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; //�趨����
                break;
        case 1:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1; //�趨����
                break;
        case 2:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //�趨����
                break;
        case 3:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; //�趨����
                break;
        case 4:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4; //�趨����
                break;
        case 5:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5; //�趨����
                break;
        case 6:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; //�趨����
                break;
        case 7:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7; //�趨����
                break;
        case 8:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; //�趨����
                break;
        case 9:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //�趨����
                break;
        case 10:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; //�趨����
                break;
        case 11:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11; //�趨����
                break;
        case 12:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12; //�趨����
                break;
        case 13:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13; //�趨����
                break;
        case 14:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14; //�趨����
                break;
        case 15:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15; //�趨����
                break;
        case 16:
                GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All; //�趨����
                break;
        }

        /*��������ģʽ*/
        GPIO_InitStructure.GPIO_Mode = mode;
        GPIO_InitStructure.GPIO_Speed = speed; //����ģʽ

        switch (gpio) //��ʼ��
        {

        // A
        case 0:
                GPIO_Init(GPIOA, &GPIO_InitStructure);
                break;

        // B
        case 1:
                GPIO_Init(GPIOB, &GPIO_InitStructure);
                break;

        // C
        case 2:
                GPIO_Init(GPIOC, &GPIO_InitStructure);
                break;

        // D
        case 3:
                GPIO_Init(GPIOD, &GPIO_InitStructure);
                break;

        // E
        case 4:
                GPIO_Init(GPIOE, &GPIO_InitStructure);
                break;

        // F
        case 5:
                GPIO_Init(GPIOF, &GPIO_InitStructure);
                break;

        // G
        case 6:
                GPIO_Init(GPIOG, &GPIO_InitStructure);
                break;
        }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      IO���
//  @param      gpio            ģ���
//  @param      date            �����ƽ״̬
//  @return     void
//  @since      v1.0
//  Sample usage:               IO_set(G9,1);
//-------------------------------------------------------------------------------------------------------------------

void IO_set(GPIO_PIN gpio_pin, u8 date)
{
        int gpio, pin;
        GPIO_TypeDef *GPIOX;

        gpio = gpio_pin / 17;
        pin = 1 << gpio_pin % 17;
        switch (gpio)
        {

        case 0:
                GPIOX = GPIOA;
                break;
        case 1:
                GPIOX = GPIOB;
                break;
        case 2:
                GPIOX = GPIOC;
                break;
        case 3:
                GPIOX = GPIOD;
                break;
        case 4:
                GPIOX = GPIOE;
                break;
        case 5:
                GPIOX = GPIOF;
                break;
        case 6:
                GPIOX = GPIOG;
                break;
        }

        if (date)
                GPIOX->BRR = pin;
        else
                GPIOX->BSRR = pin;
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      IO��ȡ��ƽ״̬
//  @param      gpio            ģ���
//  @return     void
//  @since      v1.0
//  Sample usage:               IO_read(G9);
//-------------------------------------------------------------------------------------------------------------------

uint8_t IO_read(GPIO_PIN gpio_pin)
{
        int gpio, pin;
        GPIO_TypeDef *GPIOX;

        gpio = gpio_pin / 17;
        pin = 1 << gpio_pin % 17;
        switch (gpio)
        {

        case 0:
                GPIOX = GPIOA;
                break;
        case 1:
                GPIOX = GPIOB;
                break;
        case 2:
                GPIOX = GPIOC;
                break;
        case 3:
                GPIOX = GPIOD;
                break;
        case 4:
                GPIOX = GPIOE;
                break;
        case 5:
                GPIOX = GPIOF;
                break;
        case 6:
                GPIOX = GPIOG;
                break;
        }
        return GPIO_ReadInputDataBit(GPIOX, pin);
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      IO��ת��ƽ״̬
//  @param      gpio            ģ���
//  @return     void
//  @since      v1.0
//  Sample usage:               IO_toggle(G9);
//-------------------------------------------------------------------------------------------------------------------
void IO_toggle(GPIO_PIN gpio_pin)
{
        int gpio, pin;
        uint8_t GPIO_READ;
        GPIO_TypeDef *GPIOX;
        gpio = gpio_pin / 17;
        pin = 1 << gpio_pin % 17;
        switch (gpio)
        {

        case 0:
                GPIOX = GPIOA;
                break;
        case 1:
                GPIOX = GPIOB;
                break;
        case 2:
                GPIOX = GPIOC;
                break;
        case 3:
                GPIOX = GPIOD;
                break;
        case 4:
                GPIOX = GPIOE;
                break;
        case 5:
                GPIOX = GPIOF;
                break;
        case 6:
                GPIOX = GPIOG;
                break;
        }
        GPIO_READ = GPIO_ReadOutputDataBit(GPIOX, pin);
        if (GPIO_READ)
                GPIOX->BSRR = pin;
        else
                GPIOX->BRR = pin;
}
