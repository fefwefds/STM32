#ifndef _common_h
#define _common_h


typedef unsigned char		uint8;													//  8 bits 
typedef unsigned short int	uint16;													// 16 bits 
typedef unsigned long int	uint32;													// 32 bits 
typedef unsigned long long	uint64;													// 64 bits 

typedef char				int8;													//  8 bits 
typedef short int			int16;													// 16 bits 
typedef long  int			int32;													// 32 bits 
typedef long  long			int64;													// 64 bits 

typedef volatile int8		vint8;													//  8 bits 
typedef volatile int16		vint16;													// 16 bits 
typedef volatile int32		vint32;													// 32 bits 
typedef volatile int64		vint64;													// 64 bits 

typedef volatile uint8		vuint8;													//  8 bits 
typedef volatile uint16		vuint16;												// 16 bits 
typedef volatile uint32		vuint32;												// 32 bits 
typedef volatile uint64		vuint64;												// 64 bits 



//ö��

//io
typedef enum{

     A0,A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12,A13,A14,A15,A_ALL, //0 ~16
     B0,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,B13,B14,B15,B_ALL, //17~33
     C0,C1,C2,C3,C4,C5,C6,C7,C8,C9,C10,C11,C12,C13,C14,C15,C_ALL, //34~50
     D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12,D13,D14,D15,D_ALL, //51~67
     E0,E1,E2,E3,E4,E5,E6,E7,E8,E9,E10,E11,E12,E13,E14,E15,E_ALL,
     F0,F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,F13,F14,F15,F_ALL,
     G0,G1,G2,G3,G4,G5,G6,G7,G8,G9,G10,G11,G12,G13,G14,G15,G_ALL,
}GPIO_PIN;



// typedef enum{

//      RTC_50HZ=GPIO_AF_RTC_50Hz,
//      AF0_MCO=GPIO_AF_MCO,
//      AF0_TAMPER=GPIO_AF_TAMPER,
//      AF0_SWJ=GPIO_AF_SWJ,
//      AF0_TRACE=GPIO_AF_TRACE,
     
//      //TIM
//      AF1_TIM1=GPIO_AF_TIM1,
//      AF1_TIM2=GPIO_AF_TIM2,
//      AF2_TIM3=GPIO_AF_TIM3,
//      AF2_TIM4=GPIO_AF_TIM4,
//      AF2_TIM5=GPIO_AF_TIM5,
//      AF3_TIM8=GPIO_AF_TIM8,
//      AF3_TIM9=GPIO_AF_TIM9,
//      AF3_TIM10=GPIO_AF_TIM10,
//      AF3_TIM11=GPIO_AF_TIM11,
//      AF9_TIM12=GPIO_AF_TIM12,
//      AF9_TIM13=GPIO_AF_TIM13,
//      AF9_TIM14=GPIO_AF_TIM14,
     
//      //IIC
//      AF4_I2C1=GPIO_AF_I2C1,
//      AF4_I2C2=GPIO_AF_I2C2,
//      AF4_I2C3=GPIO_AF_I2C3,
     
//      AF5_SPI1=GPIO_AF_SPI1,
//      AF5_SPI2=GPIO_AF_SPI2,
//      AF5_SPI3=GPIO_AF5_SPI3,
//      AF5_SPI4=GPIO_AF_SPI4,
//      AF5_SPI5=GPIO_AF_SPI5,
//      AF5_SPI6=GPIO_AF_SPI6,
//      AF_I2S2ext=GPIO_AF_I2S2ext,
//      AF_SAI1=GPIO_AF_SAI1,
     
//      AF7_USART1=GPIO_AF_USART1,
//      AF7_USART2=GPIO_AF_USART2,
//      AF7_USART3=GPIO_AF_USART3,
//      AF7_SPI3=GPIO_AF7_SPI3,
     
//      AF8_UART4=GPIO_AF_UART4,
//      AF8_UART5=GPIO_AF_UART5,
//      AF8_USART6=GPIO_AF_USART6,
//      AF8_UART7=GPIO_AF_UART7,
//      AF8_UART8=GPIO_AF_UART8,
     
//      AF9_CAN1=GPIO_AF_CAN1,
//      AF9_CAN2=GPIO_AF_CAN2,
     
//      AF_TIM12=GPIO_AF_TIM12,
//      AF_TIM13=GPIO_AF_TIM13,
//      AF_TIM14=GPIO_AF_TIM14,
//      AF9_I2C2=GPIO_AF9_I2C2,
//      AF9_I2C3=GPIO_AF9_I2C3,
     
//      AF10_OTG_FS=GPIO_AF_OTG_FS,
//      AF10_OTG_HS=GPIO_AF_OTG_HS,
     
//      AF11_ETH=GPIO_AF_ETH,
//      AF12_FSMC=GPIO_AF_FSMC,//407
// //     AF12_FMC=GPIO_AF_FMC,//STM32F427
     
//      AF12_OTG_HS_FS=GPIO_AF_OTG_HS_FS,
//      AF12_SDIO=GPIO_AF_SDIO,
//      AF13_DCMI=GPIO_AF_DCMI,
//      AF_LTDC=GPIO_AF_LTDC,
     
//      AF15_EVENTOUT=GPIO_AF_EVENTOUT,

// }GPIOALT_ENUM;

//��ʱ��
typedef enum{

     TIM1_CH1,TIM1_CH2,TIM1_CH3,TIM1_CH4,TIM1_ALL, //0~4
     TIM2_CH1,TIM2_CH2,TIM2_CH3,TIM2_CH4,TIM2_ALL, //5~9
     TIM3_CH1,TIM3_CH2,TIM3_CH3,TIM3_CH4,TIM3_ALL, //10~14
     TIM4_CH1,TIM4_CH2,TIM4_CH3,TIM4_CH4,TIM4_ALL, //15~19
     TIM5_CH1,TIM5_CH2,TIM5_CH3,TIM5_CH4,TIM5_ALL,
     TIM6_CH1,TIM6_CH2,TIM6_CH3,TIM6_CH4,TIM6_ALL,
     TIM7_CH1,TIM7_CH2,TIM7_CH3,TIM7_CH4,TIM7_ALL,
     TIM8_CH1,TIM8_CH2,TIM8_CH3,TIM8_CH4,TIM8_ALL,
     TIM9_CH1,TIM9_CH2,TIM9_CH3,TIM9_CH4,TIM9_ALL,
     TIM10_CH1,TIM10_CH2,TIM10_CH3,TIM10_CH4,TIM10_ALL,
     TIM11_CH1,TIM11_CH2,TIM11_CH3,TIM11_CH4,TIM11_ALL,
     TIM12_CH1,TIM12_CH2,TIM12_CH3,TIM12_CH4,TIM12_ALL,     
     TIM13_CH1,TIM13_CH2,TIM13_CH3,TIM13_CH4,TIM13_ALL,
     TIM14_CH1,TIM14_CH2,TIM14_CH3,TIM14_CH4,TIM14_ALL,
}TIMX_ENUM;

//��ʱ��ģ��ö��
typedef enum {
    
     TIMER1,
     TIMER2,
     TIMER3,
     TIMER4,
     TIMER5,
     TIMER6,
     TIMER7,
     TIMER8,
     TIMER9,
     TIMER10,
     TIMER11,
     TIMER12,
     TIMER13,
     TIMER14,

}TIMERX_ENUM;

//UART���ź궨��
typedef enum {

    USART_1=0,
    USART_2,
    USART_3,
    UART_4,
    UART_5,
    USART_6,

}UARTX_ENUM;

typedef enum {

  // USART 1  TX APB2   42MHZ
  USART1_TX_A9                                                            = A9,
  USART1_TX_B6                                                            = B6,
  // USART 1  RX  APB2   42MHZ
  USART1_RX_B7                                                            = B7,
  USART1_RX_A10                                                          = A10, 
  // USART 6  TX
  USART6_TX_C6                                                            =C6,
  USART6_TX_G14                                                          = G14,
  // USART 6  RX
  USART6_RX_C7                                                            = C7,
  USART6_RX_G9                                                            = G9,
  
  //  RX  APB1 84MHZ
  USART2_RX_A3                                                            = A3,
  USART2_RX_D6                                                            = D6,
  // USART2 _TX 
  USART2_TX_A2                                                            = A2,
  USART2_TX_D5                                                            = D5,
  // USART3  RX
  USART3_RX_B11                                                           = B11,
  USART3_RX_D9                                                             = D9 ,
  USART3_RX_C11                                                           = C11,
  // USART3  TX
  USART3_TX_B10                                                           = B10,
  USART3_TX_D8                                                             = D8, 
  USART3_TX_C10                                                           = C10,
  // UART4  RX
  USART4_RX_A1                                                             = A1, 
  USART4_RX_C11                                                           = C11,
  // UART4  TX
  USART4_TX_A0                                                             = A0,
  USART4_TX_C10                                                           = C10, 
  // UART5  RX
  
  USART5_RX_C12                                                           = C12,
  // UART5  TX
  USART5_TX_D2                                                             = D2,

}UARTX_ENUM_IO;



void nvic_init(IRQn_Type irqn, uint8 preemption_priority, uint8 sub_priority, FunctionalState status);
void nvic_interrput_enable (void);
void nvic_interrput_disable (void);

#endif
